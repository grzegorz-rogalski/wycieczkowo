/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wycieczkowo;

import java.util.ArrayList;
import javax.inject.Named;
import javax.enterprise.context.Dependent;
import org.primefaces.model.map.GeocodeResult;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import org.primefaces.event.map.GeocodeEvent;
import org.primefaces.model.map.DefaultMapModel;
import org.primefaces.model.map.LatLng;
import org.primefaces.model.map.MapModel;

/**
 *
 * @author grzegorz
 */
@Named(value = "geocodeView")
@Dependent
public class GeocodeView {

    private MapModel geoModel;
    private MapModel revGeoModel;
    private String centerGeoMap = "41.850033, -87.6500523";
    public static List<LatLng> lista = new ArrayList<LatLng>();

    @PostConstruct
    public void init() {
        geoModel = new DefaultMapModel();
        revGeoModel = new DefaultMapModel();

    }

    public void onGeocode(GeocodeEvent event) {
        List<GeocodeResult> results = event.getResults();

        if (results != null && !results.isEmpty()) {
            LatLng center = results.get(0).getLatLng();
            centerGeoMap = center.getLat() + "," + center.getLng();

            GeocodeResult result = results.get(0);
          System.out.println("<><><><><><><>" + result.getLatLng());
            LatLng a = result.getLatLng();

            lista.add(a);
            if (lista.size() == 4) {
                info();
                lista.clear();
            }
        }
    }

    public void info() {
      System.out.println("asdasdasdasdasdasdasdasdasdasd" + lista.size());
        PolylinesView.coord1 = lista.get(0);
        PolylinesView.coord2 = lista.get(1);
        PolylinesView.coord3 = lista.get(2);
        PolylinesView.coord4 = lista.get(3);

        double a, b, c, d, e = 0, f = 0;
        a = lista.get(0).getLat();
        b = lista.get(0).getLng();
        c = lista.get(1).getLat();
        d = lista.get(1).getLng();
        e += Math.acos(((Math.sin(c) * Math.sin(a)) + (Math.cos(c) * Math.cos(a))) * Math.cos(d - b));
        f += Math.sqrt(Math.pow(a - c, 2) + Math.pow(b - d, 2)) * 111.196672;

        a = lista.get(1).getLat();
        b = lista.get(1).getLng();
        c = lista.get(2).getLat();
        d = lista.get(2).getLng();
        e += Math.acos(((Math.sin(c) * Math.sin(a)) + (Math.cos(c) * Math.cos(a))) * Math.cos(d - b));
        f += Math.sqrt(Math.pow(a - c, 2) + Math.pow(b - d, 2)) * 111.196672;

        a = lista.get(2).getLat();
        b = lista.get(2).getLng();
        c = lista.get(3).getLat();
        d = lista.get(3).getLng();
        e += Math.acos(((Math.sin(c) * Math.sin(a)) + (Math.cos(c) * Math.cos(a))) * Math.cos(d - b));
        f += Math.sqrt(Math.pow(a - c, 2) + Math.pow(b - d, 2)) * 111.196672;
        /*e=Math.sqrt(((a*a)+(b*b)));
         d=acos(sin(lat1)*sin(lat2)+cos(lat1)*cos(lat2)*cos(lon1-lon2))
         
         double q,w,dz=12756.274;
         q=(d-b)*Math.cos(a*Math.PI/180);
         w=c-d;
         f=Math.sqrt(q*q+w*w)*Math.PI*dz/360;*/

        FacesContext.getCurrentInstance().addMessage(
                null, new FacesMessage(
                        FacesMessage.SEVERITY_INFO, "DŁUGOŚĆ TRASY",
                        String.valueOf(e * 100) + "km   " + String.valueOf(f) + "km"));

    }

    public MapModel getGeoModel() {
        return geoModel;
    }

    public MapModel getRevGeoModel() {
        return revGeoModel;
    }

    public String getCenterGeoMap() {
        return centerGeoMap;
    }

}
