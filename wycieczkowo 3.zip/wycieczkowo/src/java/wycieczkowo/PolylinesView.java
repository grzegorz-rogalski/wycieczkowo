package wycieczkowo;

import javax.annotation.PostConstruct;
import javax.inject.Named;
import javax.enterprise.context.Dependent;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import org.primefaces.event.map.OverlaySelectEvent;
import org.primefaces.model.map.DefaultMapModel;
import org.primefaces.model.map.LatLng;
import org.primefaces.model.map.MapModel;
import org.primefaces.model.map.Polyline;

/**
 *
 * @author grzegorz
 */
@Named(value = "polylinesView")
@Dependent
public class PolylinesView {

    private MapModel polylineModel;
     public static LatLng coord1 = new LatLng(36.879466, 30.667648);
     public static LatLng coord2 = new LatLng(36.883707, 30.689216);
     public static LatLng coord3 = new LatLng(36.879703, 30.706707);
     public static LatLng coord4 = new LatLng(36.885233, 30.702323);
    @PostConstruct
    public void init() {
        polylineModel = new DefaultMapModel();
          
        Polyline polyline = new Polyline();
        polyline.getPaths().add(coord1);
        polyline.getPaths().add(coord2);
        polyline.getPaths().add(coord3);
        polyline.getPaths().add(coord4);
          
        polyline.setStrokeWeight(3);
        polyline.setStrokeColor("#FF0033");
        polyline.setStrokeOpacity(0.7);
          
        polylineModel.addOverlay(polyline);
    }
  
    public MapModel getPolylineModel() {
        return polylineModel;
    }
  
    public void onPolylineSelect(OverlaySelectEvent event) {
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO,
                        "Polyline Selected", null));
    }
    
}
