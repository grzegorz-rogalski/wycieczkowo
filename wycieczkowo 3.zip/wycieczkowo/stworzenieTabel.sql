

CREATE TABLE person(
id INTEGER PRIMARY KEY NOT NULL,
imie VARCHAR(100),
nazwisko VARCHAR(100),
email VARCHAR(100),
nrTel VARCHAR(100)
);

CREATE TABLE infoUsera(
id INTEGER PRIMARY KEY NOT NULL,
posiadAuto BOOLEAN,
palacy BOOLEAN,
rozmowny BOOLEAN,
lubiImprezy BOOLEAN,
dodatkowe VARCHAR(400)
);

CREATE TABLE wycieczka(
id INTEGER PRIMARY KEY NOT NULL,
zagraniczna BOOLEAN,
krajowa BOOLEAN,
transport VARCHAR(200),
cel VARCHAR(200),
ileOsob INTEGER,
kosztZaOsobe INTEGER,
dataStartu DATE,
dataKonca DATE,
dodatkowe VARCHAR(1000)
);

CREATE TABLE gdzie(
id INTEGER PRIMARY KEY NOT NULL,
miejsce VARCHAR(30),
miejsceGPS VARCHAR(50)
);
