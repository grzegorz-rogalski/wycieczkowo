/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wycieczkowo;

import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.inject.Named;
import javax.enterprise.context.Dependent;
import org.primefaces.model.map.DefaultMapModel;
import org.primefaces.model.map.LatLng;
import org.primefaces.model.map.MapModel;
import org.primefaces.model.map.Marker;

/**
 *
 * @author grzegorz
 */
@Named(value = "markersView")
@Dependent
public class MarkersView implements Serializable{
  
    private MapModel simpleModel;
    public String wspolzedne;
    GdzieController a;
    
    @PostConstruct
    public void init() {
        simpleModel = new DefaultMapModel();
        
        //Shared coordinates
        
        //LatLng coord1 = new LatLng(
         //       Double.parseDouble(wspolzedne.substring(0, 9)), 
           //     Double.parseDouble(wspolzedne.substring(11, 20)));
        LatLng coord2 = new LatLng(36.883707, 30.689216);
        LatLng coord3 = new LatLng(36.879703, 30.706707);
        LatLng coord4 = new LatLng(36.885233, 30.702323);
          
        //Basic marker
        //simpleModel.addOverlay(new Marker(coord1, "Konyaalti"));
       // simpleModel.addOverlay(new Marker(coord2, "Ataturk Parki"));
       // simpleModel.addOverlay(new Marker(coord3, "Karaalioglu Parki"));
        simpleModel.addOverlay(new Marker(coord4, "Kaleici"));
    }
  
    public MapModel getSimpleModel() {
        return simpleModel;
    }

  
    public String getWspolzedne() {
        return wspolzedne;
    }

    public void setWspolzedne(String wspolzedne) {
        this.wspolzedne = wspolzedne;
        /*System.out.println("<<<<<<<<<<<"+ 
                Double.parseDouble(wspolzedne.substring(0, 9)) 
                +"<>"+Double.parseDouble(wspolzedne.substring(11, 20)));*/
        //LatLng coord2 = new LatLng(36.883707, 30.689216);
        //simpleModel.addOverlay(new Marker(coord2, "Ataturk Parki"));
    }
    
}
