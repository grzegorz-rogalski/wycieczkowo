/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wycieczkowo;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author grzegorz
 */
@Entity
@Table(name = "WYCIECZKA")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Wycieczka.findAll", query = "SELECT w FROM Wycieczka w"),
    @NamedQuery(name = "Wycieczka.findById", query = "SELECT w FROM Wycieczka w WHERE w.id = :id"),
    @NamedQuery(name = "Wycieczka.findByZagraniczna", query = "SELECT w FROM Wycieczka w WHERE w.zagraniczna = :zagraniczna"),
    @NamedQuery(name = "Wycieczka.findByKrajowa", query = "SELECT w FROM Wycieczka w WHERE w.krajowa = :krajowa"),
    @NamedQuery(name = "Wycieczka.findByTransport", query = "SELECT w FROM Wycieczka w WHERE w.transport = :transport"),
    @NamedQuery(name = "Wycieczka.findByCel", query = "SELECT w FROM Wycieczka w WHERE w.cel = :cel"),
    @NamedQuery(name = "Wycieczka.findByIleosob", query = "SELECT w FROM Wycieczka w WHERE w.ileosob = :ileosob"),
    @NamedQuery(name = "Wycieczka.findByKosztzaosobe", query = "SELECT w FROM Wycieczka w WHERE w.kosztzaosobe = :kosztzaosobe"),
    @NamedQuery(name = "Wycieczka.findByDatastartu", query = "SELECT w FROM Wycieczka w WHERE w.datastartu = :datastartu"),
    @NamedQuery(name = "Wycieczka.findByDatakonca", query = "SELECT w FROM Wycieczka w WHERE w.datakonca = :datakonca"),
    @NamedQuery(name = "Wycieczka.findByDodatkowe", query = "SELECT w FROM Wycieczka w WHERE w.dodatkowe = :dodatkowe")})
public class Wycieczka implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Integer id;
    @Column(name = "ZAGRANICZNA")
    private Boolean zagraniczna;
    @Column(name = "KRAJOWA")
    private Boolean krajowa;
    @Size(max = 200)
    @Column(name = "TRANSPORT")
    private String transport;
    @Size(max = 200)
    @Column(name = "CEL")
    private String cel;
    @Column(name = "ILEOSOB")
    private Integer ileosob;
    @Column(name = "KOSZTZAOSOBE")
    private Integer kosztzaosobe;
    @Column(name = "DATASTARTU")
    @Temporal(TemporalType.DATE)
    private Date datastartu;
    @Column(name = "DATAKONCA")
    @Temporal(TemporalType.DATE)
    private Date datakonca;
    @Size(max = 1000)
    @Column(name = "DODATKOWE")
    private String dodatkowe;

    public Wycieczka() {
    }

    public Wycieczka(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Boolean getZagraniczna() {
        return zagraniczna;
    }

    public void setZagraniczna(Boolean zagraniczna) {
        this.zagraniczna = zagraniczna;
    }

    public Boolean getKrajowa() {
        return krajowa;
    }

    public void setKrajowa(Boolean krajowa) {
        this.krajowa = krajowa;
    }

    public String getTransport() {
        return transport;
    }

    public void setTransport(String transport) {
        this.transport = transport;
    }

    public String getCel() {
        return cel;
    }

    public void setCel(String cel) {
        this.cel = cel;
    }

    public Integer getIleosob() {
        return ileosob;
    }

    public void setIleosob(Integer ileosob) {
        this.ileosob = ileosob;
    }

    public Integer getKosztzaosobe() {
        return kosztzaosobe;
    }

    public void setKosztzaosobe(Integer kosztzaosobe) {
        this.kosztzaosobe = kosztzaosobe;
    }

    public Date getDatastartu() {
        return datastartu;
    }

    public void setDatastartu(Date datastartu) {
        this.datastartu = datastartu;
    }

    public Date getDatakonca() {
        return datakonca;
    }

    public void setDatakonca(Date datakonca) {
        this.datakonca = datakonca;
    }

    public String getDodatkowe() {
        return dodatkowe;
    }

    public void setDodatkowe(String dodatkowe) {
        this.dodatkowe = dodatkowe;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Wycieczka)) {
            return false;
        }
        Wycieczka other = (Wycieczka) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "wycieczkowo.Wycieczka[ id=" + id + " ]";
    }
    
}
